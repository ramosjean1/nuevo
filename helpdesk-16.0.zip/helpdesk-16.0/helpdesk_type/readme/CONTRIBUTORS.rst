* `Open Source Integrators <https://www.opensourceintegrators.com>`_:

  * Maxime Chambreuil <mchambreuil@opensourceintegrators.com>

* `Konos <https://www.konos.cl>`_:

  * Nelson Sanchez <nramirez@konos.cl>

* `Solvos <https://www.solvos.es>`_:

  * David Alonso <david.alonso@solvos.es>
